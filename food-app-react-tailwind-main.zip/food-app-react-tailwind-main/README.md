![Untitled design](https://user-images.githubusercontent.com/65420004/180659905-25df4a63-6f62-4a09-85a5-86803d7796b2.jpg)


# Build A React JS Website Styled With Tailwind CSS

## Run npm install to install the necessary dependencies

 All of the data/images to simulate API responses are located at src/data/data.js

This was a fun little project consisting of React & Tailwind which is a super powerful frontend combination you can used to quickly build websites. In this build I focus on adding a little extra javascript with the array filter method to filter out specific food types and pricing categories.
